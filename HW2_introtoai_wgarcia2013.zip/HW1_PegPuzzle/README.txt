In order to use this program, first select a value for N from the numeric up down.  

Next click "Choose Start" and click on a peg to take it off the board. This can be repeated until the desired start state is acheived. 

Click on "Choose Goal" to designate the peg that will be the goal state. This can be repeated until the desired goal state is acheived. 

Click Search to commence the searching. 

If a solution is found, it will appear in the Output box. 

The solution is represented as a row of buttons numbered from 1 to the last step. 

Each step can be clicked to view the board at that state of the solution, and the buttons can be clicked seqeuentially to view the full solution. 

Click the Reset button to clear the screen and start a new board search. 